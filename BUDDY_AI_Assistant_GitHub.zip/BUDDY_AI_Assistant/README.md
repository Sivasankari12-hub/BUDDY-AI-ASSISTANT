# BUDDY — Secure Offline Desktop AI Assistant with Memory

BUDDY is a Python console assistant that uses a local Ollama model to chat, remembers recent conversation history in SQLite, speaks responses, manages temporary tasks, opens YouTube searches, takes screenshots, and records the screen.

## Features
- Tamil-English conversational assistant (prompted to use a simple Tamil-English mix)
- Local AI responses through Ollama and the `llama3.2` model
- Conversation history stored locally in `buddy_memory.db` (SQLite)
- Text-to-speech using `pyttsx3`
- Add, show, and delete tasks (tasks reset when the program closes)
- YouTube search, screenshot capture, and screen recording

## Requirements
- Python 3.10 or newer recommended
- Ollama installed and running locally
- The Ollama model `llama3.2` downloaded
- Desktop environment with screen capture permissions for screenshot/recording features

## Setup (Windows)
1. Install Python and Ollama.
2. Download the model in a terminal:
   ```bash
   ollama pull llama3.2
   ```
3. Start Ollama (often it runs in the background after installation).
4. Open a terminal in this project folder and install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
5. Run the assistant:
   ```bash
   python buddy.py
   ```

## Example commands
- `date` or `time`
- `add task practise SQL`
- `show task`
- `delete task 1`
- `youtube Python pandas tutorial`
- `screenshot`
- `screen record`

Type `exit`, `bye`, or `quit` to close Buddy.

## Notes
- The Python application is designed to run locally, but installing packages and downloading the Ollama model require internet access initially.
- Do not upload your personal `buddy_memory.db`, screenshots, or recordings to a public repository.
- `buddy_memory.db`, `shot_*.png`, and `record_*.avi` are ignored by Git in this project.
- The project requires a local desktop session; it will not run as an interactive desktop assistant directly on GitHub Pages.
